export class Toq<TMock extends object> {
    private callstackSymbol: symbol = Symbol("Call Stack");

    private configurations: MockConfiguration[] = [];

    public setup<TReturn>(setup: (config: TMock) => TReturn | void): Configuration<TReturn> {
        let configObject = this.buildConfigObject();
        setup(configObject);
        let callstack = configObject[this.callstackSymbol];
        let configuration = new MockConfiguration(callstack);
        this.configurations.push(configuration);
        return configuration.asPublic<TReturn>();
    }

    private toName(thing: string | number | symbol): string {
        if (typeof (thing) == "symbol") {
            return Symbol.keyFor(thing as symbol);
        } else {
            return (thing as string | number).toString();
        }
    }

    public get object(): TMock {
        let callstack: Activation[] = [];

        let buildAnon = (): TMock => {
            let handler: ProxyHandler<any> = {
                get: (target, prop) => {
                    callstack.push({
                        name: prop,
                        type: ActivationType.PropertyGet
                    });

                    let done = this.configurations.filter(x => x.isDone(callstack));
                    if (done.length > 0)
                        return done[0].call([]);

                    if (!this.configurations.some(x => x.matches(callstack)))
                        throw new TypeError("Call " + this.toName(prop) + " was not set up");

                    return buildAnon();
                },
                set: (target, prop, value) => {
                    callstack.push({
                        name: prop,
                        type: ActivationType.PropetySet,
                        parameters: [value]
                    });

                    let done = this.configurations.filter(x => x.isDone(callstack));
                    if (done.length > 0) {
                        done[0].call([value]);
                        return true;
                    }

                    if (!this.configurations.some(x => x.matches(callstack)))
                        throw new TypeError("Call " + this.toName(prop) + " was not set up");

                    return true;
                },
                apply: (target, thisArg, argumentsList) => {
                    callstack.push({
                        type: ActivationType.FunctionCall,
                        parameters: [...argumentsList]
                    });

                    let done = this.configurations.filter(x => x.isDone(callstack));
                    if (done.length > 0)
                        return done[0].call([...argumentsList]);

                    if (!this.configurations.some(x => x.matches(callstack)))
                        throw new TypeError("Call was not set up");

                    return buildAnon();
                }
            };

            return new Proxy(() => { }, handler);
        }

        return buildAnon();
    }

    private buildConfigObject(callstack: Activation[] = []): any {
        let handler: ProxyHandler<any> = {
            get: (target, prop) => {
                if (prop == this.callstackSymbol)
                    return callstack;

                callstack.push({
                    name: prop,
                    type: ActivationType.PropertyGet
                });
                return this.buildConfigObject(callstack);
            },
            set: (target, prop, value) => {
                callstack.push({
                    name: prop,
                    type: ActivationType.PropetySet,
                    parameters: [value]
                });
                return true;
            },
            apply: (target, thisArg, argumentsList) => {
                callstack.push({
                    type: ActivationType.FunctionCall,
                    parameters: [...argumentsList]
                });
                return this.buildConfigObject(callstack);
            }
        };
        return new Proxy(() => { }, handler);
    }
}

enum ActivationType {
    FunctionCall,
    PropertyGet,
    PropetySet
}

interface Activation {
    name?: string | number | symbol;
    type: ActivationType;
    parameters?: Array<any>;
}

function ActivationMatches(a: Activation, b: Activation) {
    if (a.type != b.type)
        return false;

    if (a.name != b.name)
        return false;

    if ((a.parameters == null) != (b.parameters == null))
        return false;

    if (a.parameters == b.parameters)
        return true;

    if (!a.parameters.every((a, i) => a == b.parameters[i]))
        return false;

    return true;
}

class Configuration<TReturn> {
    constructor(private config: MockConfiguration) {

    }

    returns(value: TReturn) {
        this.config.return = value;
    }
}

class MockConfiguration {
    constructor(private callstack: Activation[]) {

    }

    return: any;

    call(params: any[]): any {
        return this.return;
    }

    matches(candidate: Activation[]): boolean {
        if (candidate.length > this.callstack.length)
            return false;

        return candidate.every((c, i) => ActivationMatches(c, this.callstack[i]));
    }

    isDone(candidate: Activation[]): boolean {
        return this.matches(candidate) && candidate.length == this.callstack.length;
    }

    asPublic<TReturn>(): Configuration<TReturn> {
        return new Configuration<TReturn>(this);
    }
}

export function classify<TInterface>(): new () => TInterface {
    interface ctor {
        new(): TInterface
    }

    return {} as ctor;
}