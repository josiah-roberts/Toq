export * from './lib/Toq'
import {Toq} from './lib/Toq'

class Thing
{
    public stringyBoi: string;
    public anotherThing: Thing;
    public callMe(int: number, s: string): Thing {
        return new Thing();
    }
}

var x = new Toq<Thing>();
x.setup(t => t.callMe(12, "corn").stringyBoi).returns("hey there");
x.setup(t => t.callMe(12, "corn").callMe(0, "cake")).returns(new Thing());
x.setup(t => t.callMe(12, "something else")).returns(null);

let heyThere = x.object.callMe(12, "corn").stringyBoi;
let other = x.object.callMe(12, "something else");
let shouldBeAThing = x.object.callMe(12, "corn").callMe(0, "cake");
heyThere.toString();
